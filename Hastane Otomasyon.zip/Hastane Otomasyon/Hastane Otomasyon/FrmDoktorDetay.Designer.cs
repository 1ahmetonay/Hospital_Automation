﻿namespace Hastane_Otomasyon
{
    partial class FrmDoktorDetay
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            groupBox1 = new GroupBox();
            LblAdSoyad = new Label();
            LblTC = new Label();
            label2 = new Label();
            label1 = new Label();
            groupBox2 = new GroupBox();
            RtxtRandevuDetay = new RichTextBox();
            groupBox3 = new GroupBox();
            BtnÇıkış = new Button();
            Btnduyurular = new Button();
            BtnBilgiDüzenle = new Button();
            groupBox4 = new GroupBox();
            dataGridView1 = new DataGridView();
            groupBox1.SuspendLayout();
            groupBox2.SuspendLayout();
            groupBox3.SuspendLayout();
            groupBox4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            SuspendLayout();
            // 
            // groupBox1
            // 
            groupBox1.Anchor = AnchorStyles.None;
            groupBox1.Controls.Add(LblAdSoyad);
            groupBox1.Controls.Add(LblTC);
            groupBox1.Controls.Add(label2);
            groupBox1.Controls.Add(label1);
            groupBox1.Location = new Point(4, 5);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(321, 178);
            groupBox1.TabIndex = 0;
            groupBox1.TabStop = false;
            groupBox1.Text = "Doktor Bilgi";
            // 
            // LblAdSoyad
            // 
            LblAdSoyad.AutoSize = true;
            LblAdSoyad.Location = new Point(137, 100);
            LblAdSoyad.Name = "LblAdSoyad";
            LblAdSoyad.Size = new Size(57, 27);
            LblAdSoyad.TabIndex = 5;
            LblAdSoyad.Text = "Null";
            // 
            // LblTC
            // 
            LblTC.AutoSize = true;
            LblTC.Location = new Point(137, 52);
            LblTC.Name = "LblTC";
            LblTC.Size = new Size(166, 27);
            LblTC.TabIndex = 6;
            LblTC.Text = "00000000000";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(17, 100);
            label2.Name = "label2";
            label2.Size = new Size(114, 27);
            label2.TabIndex = 7;
            label2.Text = "Ad Soyad:";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(47, 52);
            label1.Name = "label1";
            label1.Size = new Size(84, 27);
            label1.TabIndex = 4;
            label1.Text = "TC No:";
            // 
            // groupBox2
            // 
            groupBox2.Anchor = AnchorStyles.None;
            groupBox2.Controls.Add(RtxtRandevuDetay);
            groupBox2.Location = new Point(4, 225);
            groupBox2.Name = "groupBox2";
            groupBox2.Size = new Size(321, 270);
            groupBox2.TabIndex = 1;
            groupBox2.TabStop = false;
            groupBox2.Text = "Randevu Detay";
            // 
            // RtxtRandevuDetay
            // 
            RtxtRandevuDetay.Location = new Point(6, 33);
            RtxtRandevuDetay.Name = "RtxtRandevuDetay";
            RtxtRandevuDetay.Size = new Size(309, 231);
            RtxtRandevuDetay.TabIndex = 0;
            RtxtRandevuDetay.Text = "";
            // 
            // groupBox3
            // 
            groupBox3.Anchor = AnchorStyles.None;
            groupBox3.Controls.Add(BtnÇıkış);
            groupBox3.Controls.Add(Btnduyurular);
            groupBox3.Controls.Add(BtnBilgiDüzenle);
            groupBox3.Location = new Point(4, 531);
            groupBox3.Name = "groupBox3";
            groupBox3.Size = new Size(321, 187);
            groupBox3.TabIndex = 2;
            groupBox3.TabStop = false;
            groupBox3.Text = "Hızlı Erişim";
            // 
            // BtnÇıkış
            // 
            BtnÇıkış.BackColor = Color.FromArgb(192, 0, 0);
            BtnÇıkış.Location = new Point(17, 115);
            BtnÇıkış.Name = "BtnÇıkış";
            BtnÇıkış.Size = new Size(284, 63);
            BtnÇıkış.TabIndex = 6;
            BtnÇıkış.Text = "Çıkış";
            BtnÇıkış.UseVisualStyleBackColor = false;
            BtnÇıkış.Click += BtnÇıkış_Click;
            // 
            // Btnduyurular
            // 
            Btnduyurular.BackColor = Color.CadetBlue;
            Btnduyurular.Location = new Point(162, 44);
            Btnduyurular.Name = "Btnduyurular";
            Btnduyurular.Size = new Size(139, 63);
            Btnduyurular.TabIndex = 5;
            Btnduyurular.Text = "Duyurular";
            Btnduyurular.UseVisualStyleBackColor = false;
            Btnduyurular.Click += Btnduyurular_Click;
            // 
            // BtnBilgiDüzenle
            // 
            BtnBilgiDüzenle.BackColor = Color.CadetBlue;
            BtnBilgiDüzenle.Location = new Point(17, 44);
            BtnBilgiDüzenle.Name = "BtnBilgiDüzenle";
            BtnBilgiDüzenle.Size = new Size(139, 63);
            BtnBilgiDüzenle.TabIndex = 4;
            BtnBilgiDüzenle.Text = "Bilgi Düzenle";
            BtnBilgiDüzenle.UseVisualStyleBackColor = false;
            BtnBilgiDüzenle.Click += BtnBilgiDüzenle_Click;
            // 
            // groupBox4
            // 
            groupBox4.Anchor = AnchorStyles.None;
            groupBox4.Controls.Add(dataGridView1);
            groupBox4.Location = new Point(346, 12);
            groupBox4.Name = "groupBox4";
            groupBox4.Size = new Size(1005, 706);
            groupBox4.TabIndex = 3;
            groupBox4.TabStop = false;
            groupBox4.Text = "Randevu Listesi";
            // 
            // dataGridView1
            // 
            dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Dock = DockStyle.Fill;
            dataGridView1.Location = new Point(3, 30);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.RowHeadersWidth = 51;
            dataGridView1.Size = new Size(999, 673);
            dataGridView1.TabIndex = 0;
            dataGridView1.CellClick += dataGridView1_CellClick;
            // 
            // FrmDoktorDetay
            // 
            AutoScaleDimensions = new SizeF(14F, 27F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.LightSeaGreen;
            ClientSize = new Size(1362, 743);
            Controls.Add(groupBox4);
            Controls.Add(groupBox3);
            Controls.Add(groupBox2);
            Controls.Add(groupBox1);
            Font = new Font("Georgia", 13.8F, FontStyle.Regular, GraphicsUnit.Point, 162);
            Margin = new Padding(5, 4, 5, 4);
            Name = "FrmDoktorDetay";
            Text = "Doktor Detay";
            WindowState = FormWindowState.Maximized;
            Load += FrmDoktorDetay_Load;
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            groupBox2.ResumeLayout(false);
            groupBox3.ResumeLayout(false);
            groupBox4.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private GroupBox groupBox1;
        private GroupBox groupBox2;
        private GroupBox groupBox3;
        private GroupBox groupBox4;
        private DataGridView dataGridView1;
        private Label LblAdSoyad;
        private Label LblTC;
        private Label label2;
        private Label label1;
        private RichTextBox RtxtRandevuDetay;
        private Button BtnBilgiDüzenle;
        private Button BtnÇıkış;
        private Button Btnduyurular;
    }
}