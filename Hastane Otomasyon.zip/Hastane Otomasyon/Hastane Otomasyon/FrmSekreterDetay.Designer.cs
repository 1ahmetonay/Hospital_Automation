﻿namespace Hastane_Otomasyon
{
    partial class FrmSekreterDetay
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            groupBox1 = new GroupBox();
            LblAdSoyad = new Label();
            LblTC = new Label();
            label2 = new Label();
            label1 = new Label();
            groupBox2 = new GroupBox();
            BtnOlustur = new Button();
            RtxtDuyuru = new RichTextBox();
            groupBox3 = new GroupBox();
            BtnKaydet = new Button();
            ChbDurum = new CheckBox();
            Txtİd = new TextBox();
            CmbBrans = new ComboBox();
            label4 = new Label();
            MskdSaat = new MaskedTextBox();
            MskdTxtTCNo = new MaskedTextBox();
            MskdTxtTarih = new MaskedTextBox();
            CmbDoktor = new ComboBox();
            label8 = new Label();
            label7 = new Label();
            label6 = new Label();
            label5 = new Label();
            label3 = new Label();
            groupBox4 = new GroupBox();
            DgwBrans = new DataGridView();
            groupBox5 = new GroupBox();
            DgwDoktorlar = new DataGridView();
            groupBox6 = new GroupBox();
            button1 = new Button();
            BtnRandevuListe = new Button();
            BtnBransPaneli = new Button();
            BtnDoktorPaneli = new Button();
            groupBox1.SuspendLayout();
            groupBox2.SuspendLayout();
            groupBox3.SuspendLayout();
            groupBox4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)DgwBrans).BeginInit();
            groupBox5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)DgwDoktorlar).BeginInit();
            groupBox6.SuspendLayout();
            SuspendLayout();
            // 
            // groupBox1
            // 
            groupBox1.Anchor = AnchorStyles.None;
            groupBox1.Controls.Add(LblAdSoyad);
            groupBox1.Controls.Add(LblTC);
            groupBox1.Controls.Add(label2);
            groupBox1.Controls.Add(label1);
            groupBox1.Location = new Point(16, 16);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(366, 182);
            groupBox1.TabIndex = 0;
            groupBox1.TabStop = false;
            groupBox1.Text = "Sekreter Bilgi";
            // 
            // LblAdSoyad
            // 
            LblAdSoyad.AutoSize = true;
            LblAdSoyad.Location = new Point(160, 102);
            LblAdSoyad.Name = "LblAdSoyad";
            LblAdSoyad.Size = new Size(57, 27);
            LblAdSoyad.TabIndex = 9;
            LblAdSoyad.Text = "Null";
            // 
            // LblTC
            // 
            LblTC.AutoSize = true;
            LblTC.Location = new Point(160, 54);
            LblTC.Name = "LblTC";
            LblTC.Size = new Size(166, 27);
            LblTC.TabIndex = 10;
            LblTC.Text = "00000000000";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(40, 102);
            label2.Name = "label2";
            label2.Size = new Size(114, 27);
            label2.TabIndex = 11;
            label2.Text = "Ad Soyad:";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(70, 54);
            label1.Name = "label1";
            label1.Size = new Size(84, 27);
            label1.TabIndex = 8;
            label1.Text = "TC No:";
            // 
            // groupBox2
            // 
            groupBox2.Anchor = AnchorStyles.None;
            groupBox2.Controls.Add(BtnOlustur);
            groupBox2.Controls.Add(RtxtDuyuru);
            groupBox2.Location = new Point(16, 198);
            groupBox2.Name = "groupBox2";
            groupBox2.Size = new Size(366, 332);
            groupBox2.TabIndex = 1;
            groupBox2.TabStop = false;
            groupBox2.Text = "Duyuru Oluştur";
            // 
            // BtnOlustur
            // 
            BtnOlustur.BackColor = Color.CadetBlue;
            BtnOlustur.Location = new Point(6, 260);
            BtnOlustur.Name = "BtnOlustur";
            BtnOlustur.Size = new Size(354, 66);
            BtnOlustur.TabIndex = 1;
            BtnOlustur.Text = "Oluştur";
            BtnOlustur.UseVisualStyleBackColor = false;
            BtnOlustur.Click += BtnOlustur_Click;
            // 
            // RtxtDuyuru
            // 
            RtxtDuyuru.Location = new Point(6, 33);
            RtxtDuyuru.Name = "RtxtDuyuru";
            RtxtDuyuru.Size = new Size(354, 221);
            RtxtDuyuru.TabIndex = 0;
            RtxtDuyuru.Text = "";
            // 
            // groupBox3
            // 
            groupBox3.Anchor = AnchorStyles.None;
            groupBox3.Controls.Add(BtnKaydet);
            groupBox3.Controls.Add(ChbDurum);
            groupBox3.Controls.Add(Txtİd);
            groupBox3.Controls.Add(CmbBrans);
            groupBox3.Controls.Add(label4);
            groupBox3.Controls.Add(MskdSaat);
            groupBox3.Controls.Add(MskdTxtTCNo);
            groupBox3.Controls.Add(MskdTxtTarih);
            groupBox3.Controls.Add(CmbDoktor);
            groupBox3.Controls.Add(label8);
            groupBox3.Controls.Add(label7);
            groupBox3.Controls.Add(label6);
            groupBox3.Controls.Add(label5);
            groupBox3.Controls.Add(label3);
            groupBox3.Location = new Point(388, 16);
            groupBox3.Name = "groupBox3";
            groupBox3.Size = new Size(422, 514);
            groupBox3.TabIndex = 2;
            groupBox3.TabStop = false;
            groupBox3.Text = "Randevu Paneli";
            // 
            // BtnKaydet
            // 
            BtnKaydet.BackColor = Color.Green;
            BtnKaydet.Location = new Point(34, 400);
            BtnKaydet.Name = "BtnKaydet";
            BtnKaydet.Size = new Size(354, 66);
            BtnKaydet.TabIndex = 22;
            BtnKaydet.Text = "Kaydet ";
            BtnKaydet.UseVisualStyleBackColor = false;
            BtnKaydet.Click += BtnKaydet_Click;
            // 
            // ChbDurum
            // 
            ChbDurum.AutoSize = true;
            ChbDurum.Location = new Point(177, 343);
            ChbDurum.Name = "ChbDurum";
            ChbDurum.Size = new Size(106, 31);
            ChbDurum.TabIndex = 21;
            ChbDurum.Text = "Durum";
            ChbDurum.UseVisualStyleBackColor = true;
            // 
            // Txtİd
            // 
            Txtİd.Location = new Point(141, 277);
            Txtİd.Name = "Txtİd";
            Txtİd.Size = new Size(213, 34);
            Txtİd.TabIndex = 20;
            // 
            // CmbBrans
            // 
            CmbBrans.FormattingEnabled = true;
            CmbBrans.Location = new Point(141, 46);
            CmbBrans.Name = "CmbBrans";
            CmbBrans.Size = new Size(213, 35);
            CmbBrans.TabIndex = 16;
            CmbBrans.SelectedIndexChanged += CmbBrans_SelectedIndexChanged;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(54, 54);
            label4.Name = "label4";
            label4.Size = new Size(85, 27);
            label4.TabIndex = 10;
            label4.Text = "Branş :";
            // 
            // MskdSaat
            // 
            MskdSaat.Location = new Point(141, 231);
            MskdSaat.Mask = "00:00";
            MskdSaat.Name = "MskdSaat";
            MskdSaat.Size = new Size(213, 34);
            MskdSaat.TabIndex = 19;
            MskdSaat.ValidatingType = typeof(DateTime);
            // 
            // MskdTxtTCNo
            // 
            MskdTxtTCNo.Location = new Point(141, 185);
            MskdTxtTCNo.Mask = "000000000000";
            MskdTxtTCNo.Name = "MskdTxtTCNo";
            MskdTxtTCNo.Size = new Size(213, 34);
            MskdTxtTCNo.TabIndex = 18;
            // 
            // MskdTxtTarih
            // 
            MskdTxtTarih.Location = new Point(141, 139);
            MskdTxtTarih.Mask = "00/00/0000";
            MskdTxtTarih.Name = "MskdTxtTarih";
            MskdTxtTarih.Size = new Size(213, 34);
            MskdTxtTarih.TabIndex = 17;
            MskdTxtTarih.ValidatingType = typeof(DateTime);
            // 
            // CmbDoktor
            // 
            CmbDoktor.FormattingEnabled = true;
            CmbDoktor.Location = new Point(141, 94);
            CmbDoktor.Name = "CmbDoktor";
            CmbDoktor.Size = new Size(213, 35);
            CmbDoktor.TabIndex = 15;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Location = new Point(92, 284);
            label8.Name = "label8";
            label8.Size = new Size(47, 27);
            label8.TabIndex = 14;
            label8.Text = "İd :";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(69, 238);
            label7.Name = "label7";
            label7.Size = new Size(70, 27);
            label7.TabIndex = 13;
            label7.Text = "Saat :";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(49, 192);
            label6.Name = "label6";
            label6.Size = new Size(90, 27);
            label6.TabIndex = 12;
            label6.Text = "TC No :";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(58, 146);
            label5.Name = "label5";
            label5.Size = new Size(81, 27);
            label5.TabIndex = 11;
            label5.Text = "Tarih :";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(38, 102);
            label3.Name = "label3";
            label3.Size = new Size(101, 27);
            label3.TabIndex = 9;
            label3.Text = " Doktor :";
            // 
            // groupBox4
            // 
            groupBox4.Anchor = AnchorStyles.None;
            groupBox4.Controls.Add(DgwBrans);
            groupBox4.Location = new Point(825, 16);
            groupBox4.Name = "groupBox4";
            groupBox4.Size = new Size(492, 356);
            groupBox4.TabIndex = 3;
            groupBox4.TabStop = false;
            groupBox4.Text = "Branşlar";
            // 
            // DgwBrans
            // 
            DgwBrans.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            DgwBrans.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            DgwBrans.Dock = DockStyle.Fill;
            DgwBrans.Location = new Point(3, 30);
            DgwBrans.Name = "DgwBrans";
            DgwBrans.RowHeadersWidth = 51;
            DgwBrans.Size = new Size(486, 323);
            DgwBrans.TabIndex = 0;
            // 
            // groupBox5
            // 
            groupBox5.Anchor = AnchorStyles.None;
            groupBox5.Controls.Add(DgwDoktorlar);
            groupBox5.Location = new Point(825, 386);
            groupBox5.Name = "groupBox5";
            groupBox5.Size = new Size(492, 340);
            groupBox5.TabIndex = 4;
            groupBox5.TabStop = false;
            groupBox5.Text = "Doktorlar";
            // 
            // DgwDoktorlar
            // 
            DgwDoktorlar.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            DgwDoktorlar.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            DgwDoktorlar.Dock = DockStyle.Fill;
            DgwDoktorlar.Location = new Point(3, 30);
            DgwDoktorlar.Name = "DgwDoktorlar";
            DgwDoktorlar.RowHeadersWidth = 51;
            DgwDoktorlar.Size = new Size(486, 307);
            DgwDoktorlar.TabIndex = 1;
            // 
            // groupBox6
            // 
            groupBox6.Anchor = AnchorStyles.None;
            groupBox6.Controls.Add(button1);
            groupBox6.Controls.Add(BtnRandevuListe);
            groupBox6.Controls.Add(BtnBransPaneli);
            groupBox6.Controls.Add(BtnDoktorPaneli);
            groupBox6.Location = new Point(16, 536);
            groupBox6.Name = "groupBox6";
            groupBox6.Size = new Size(800, 190);
            groupBox6.TabIndex = 5;
            groupBox6.TabStop = false;
            groupBox6.Text = "Hızlı Erişim";
            // 
            // button1
            // 
            button1.BackColor = Color.CadetBlue;
            button1.Location = new Point(602, 33);
            button1.Name = "button1";
            button1.Size = new Size(192, 151);
            button1.TabIndex = 5;
            button1.Text = "Duyurular";
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click;
            // 
            // BtnRandevuListe
            // 
            BtnRandevuListe.BackColor = Color.CadetBlue;
            BtnRandevuListe.Location = new Point(396, 33);
            BtnRandevuListe.Name = "BtnRandevuListe";
            BtnRandevuListe.Size = new Size(192, 151);
            BtnRandevuListe.TabIndex = 4;
            BtnRandevuListe.Text = "Randevu Liste";
            BtnRandevuListe.UseVisualStyleBackColor = false;
            BtnRandevuListe.Click += BtnRandevuListe_Click;
            // 
            // BtnBransPaneli
            // 
            BtnBransPaneli.BackColor = Color.CadetBlue;
            BtnBransPaneli.Location = new Point(197, 33);
            BtnBransPaneli.Name = "BtnBransPaneli";
            BtnBransPaneli.Size = new Size(183, 151);
            BtnBransPaneli.TabIndex = 3;
            BtnBransPaneli.Text = "Branş paneli";
            BtnBransPaneli.UseVisualStyleBackColor = false;
            BtnBransPaneli.Click += BtnBransPaneli_Click;
            // 
            // BtnDoktorPaneli
            // 
            BtnDoktorPaneli.BackColor = Color.CadetBlue;
            BtnDoktorPaneli.Location = new Point(6, 33);
            BtnDoktorPaneli.Name = "BtnDoktorPaneli";
            BtnDoktorPaneli.Size = new Size(183, 151);
            BtnDoktorPaneli.TabIndex = 2;
            BtnDoktorPaneli.Text = "Doktor Paneli";
            BtnDoktorPaneli.UseVisualStyleBackColor = false;
            BtnDoktorPaneli.Click += BtnDoktorPaneli_Click;
            // 
            // FrmSekreterDetay
            // 
            AutoScaleDimensions = new SizeF(14F, 27F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.LightSeaGreen;
            ClientSize = new Size(1362, 743);
            Controls.Add(groupBox6);
            Controls.Add(groupBox5);
            Controls.Add(groupBox4);
            Controls.Add(groupBox3);
            Controls.Add(groupBox2);
            Controls.Add(groupBox1);
            Font = new Font("Georgia", 13.8F, FontStyle.Regular, GraphicsUnit.Point, 162);
            Margin = new Padding(5, 4, 5, 4);
            Name = "FrmSekreterDetay";
            Text = "Sekreter Detay";
            WindowState = FormWindowState.Maximized;
            Load += FrmSekreterDetay_Load;
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            groupBox2.ResumeLayout(false);
            groupBox3.ResumeLayout(false);
            groupBox3.PerformLayout();
            groupBox4.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)DgwBrans).EndInit();
            groupBox5.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)DgwDoktorlar).EndInit();
            groupBox6.ResumeLayout(false);
            ResumeLayout(false);
        }

        #endregion

        private GroupBox groupBox1;
        private GroupBox groupBox2;
        private GroupBox groupBox3;
        private GroupBox groupBox4;
        private GroupBox groupBox5;
        private GroupBox groupBox6;
        private Label LblAdSoyad;
        private Label LblTC;
        private Label label2;
        private Label label1;
        private Button BtnOlustur;
        private RichTextBox RtxtDuyuru;
        private Button BtnRandevuListe;
        private Button BtnBransPaneli;
        private Button BtnDoktorPaneli;
        private Label label6;
        private Label label5;
        private Label label4;
        private Label label3;
        private MaskedTextBox MskdTxtTarih;
        private ComboBox CmbBrans;
        private ComboBox CmbDoktor;
        private Label label8;
        private Label label7;
        private Button BtnKaydet;
        private CheckBox ChbDurum;
        private TextBox Txtİd;
        private MaskedTextBox MskdSaat;
        private MaskedTextBox MskdTxtTCNo;
        private DataGridView DgwBrans;
        private DataGridView DgwDoktorlar;
        private Button button1;
    }
}