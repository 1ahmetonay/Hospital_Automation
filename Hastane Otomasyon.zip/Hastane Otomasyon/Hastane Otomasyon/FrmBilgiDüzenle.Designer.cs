﻿namespace Hastane_Otomasyon
{
    partial class FrmBilgiDüzenle
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmBilgiDüzenle));
            BtnBilgiGuncelle = new Button();
            pictureBox1 = new PictureBox();
            TxtSifre = new TextBox();
            MskdTel = new MaskedTextBox();
            MskdTC = new MaskedTextBox();
            TxtSoyad = new TextBox();
            TxtAd = new TextBox();
            label6 = new Label();
            label5 = new Label();
            label4 = new Label();
            label3 = new Label();
            label2 = new Label();
            label1 = new Label();
            CmbCinsiyet = new ComboBox();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // BtnBilgiGuncelle
            // 
            BtnBilgiGuncelle.Anchor = AnchorStyles.None;
            BtnBilgiGuncelle.BackColor = Color.FromArgb(0, 192, 0);
            BtnBilgiGuncelle.Font = new Font("Georgia", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 162);
            BtnBilgiGuncelle.Location = new Point(380, 470);
            BtnBilgiGuncelle.Name = "BtnBilgiGuncelle";
            BtnBilgiGuncelle.Size = new Size(193, 40);
            BtnBilgiGuncelle.TabIndex = 7;
            BtnBilgiGuncelle.Text = "Güncelle";
            BtnBilgiGuncelle.UseVisualStyleBackColor = false;
            BtnBilgiGuncelle.Click += BtnBilgiGuncelle_Click;
            // 
            // pictureBox1
            // 
            pictureBox1.Anchor = AnchorStyles.None;
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(657, 166);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(382, 344);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 28;
            pictureBox1.TabStop = false;
            // 
            // TxtSifre
            // 
            TxtSifre.Anchor = AnchorStyles.None;
            TxtSifre.Location = new Point(380, 362);
            TxtSifre.Name = "TxtSifre";
            TxtSifre.Size = new Size(193, 32);
            TxtSifre.TabIndex = 5;
            // 
            // MskdTel
            // 
            MskdTel.Anchor = AnchorStyles.None;
            MskdTel.Location = new Point(380, 313);
            MskdTel.Mask = "(999) 000-0000";
            MskdTel.Name = "MskdTel";
            MskdTel.Size = new Size(193, 32);
            MskdTel.TabIndex = 4;
            // 
            // MskdTC
            // 
            MskdTC.Anchor = AnchorStyles.None;
            MskdTC.Location = new Point(380, 264);
            MskdTC.Mask = "00000000000";
            MskdTC.Name = "MskdTC";
            MskdTC.Size = new Size(193, 32);
            MskdTC.TabIndex = 3;
            MskdTC.ValidatingType = typeof(int);
            // 
            // TxtSoyad
            // 
            TxtSoyad.Anchor = AnchorStyles.None;
            TxtSoyad.Location = new Point(380, 215);
            TxtSoyad.Name = "TxtSoyad";
            TxtSoyad.Size = new Size(193, 32);
            TxtSoyad.TabIndex = 2;
            // 
            // TxtAd
            // 
            TxtAd.Anchor = AnchorStyles.None;
            TxtAd.Location = new Point(380, 166);
            TxtAd.Name = "TxtAd";
            TxtAd.Size = new Size(193, 32);
            TxtAd.TabIndex = 1;
            // 
            // label6
            // 
            label6.Anchor = AnchorStyles.None;
            label6.AutoSize = true;
            label6.Font = new Font("Modern No. 20", 16.2F);
            label6.Location = new Point(271, 418);
            label6.Name = "label6";
            label6.Size = new Size(110, 30);
            label6.TabIndex = 20;
            label6.Text = "Cinsiyet:";
            // 
            // label5
            // 
            label5.Anchor = AnchorStyles.None;
            label5.AutoSize = true;
            label5.Font = new Font("Modern No. 20", 16.2F);
            label5.Location = new Point(307, 369);
            label5.Name = "label5";
            label5.Size = new Size(76, 30);
            label5.TabIndex = 19;
            label5.Text = "Şifre:";
            // 
            // label4
            // 
            label4.Anchor = AnchorStyles.None;
            label4.AutoSize = true;
            label4.Font = new Font("Modern No. 20", 16.2F);
            label4.Location = new Point(278, 320);
            label4.Name = "label4";
            label4.Size = new Size(105, 30);
            label4.TabIndex = 18;
            label4.Text = "Telefon:";
            // 
            // label3
            // 
            label3.Anchor = AnchorStyles.None;
            label3.AutoSize = true;
            label3.Font = new Font("Modern No. 20", 16.2F);
            label3.Location = new Point(289, 271);
            label3.Name = "label3";
            label3.Size = new Size(90, 30);
            label3.TabIndex = 17;
            label3.Text = "TC No:";
            // 
            // label2
            // 
            label2.Anchor = AnchorStyles.None;
            label2.AutoSize = true;
            label2.Font = new Font("Modern No. 20", 16.2F);
            label2.Location = new Point(293, 222);
            label2.Name = "label2";
            label2.Size = new Size(87, 30);
            label2.TabIndex = 16;
            label2.Text = "Soyad:";
            // 
            // label1
            // 
            label1.Anchor = AnchorStyles.None;
            label1.AutoSize = true;
            label1.Font = new Font("Modern No. 20", 16.2F);
            label1.Location = new Point(326, 173);
            label1.Name = "label1";
            label1.Size = new Size(52, 30);
            label1.TabIndex = 15;
            label1.Text = "Ad:";
            // 
            // CmbCinsiyet
            // 
            CmbCinsiyet.Anchor = AnchorStyles.None;
            CmbCinsiyet.FormattingEnabled = true;
            CmbCinsiyet.ItemHeight = 25;
            CmbCinsiyet.Items.AddRange(new object[] { "Kadın", "Erkek" });
            CmbCinsiyet.Location = new Point(380, 415);
            CmbCinsiyet.Name = "CmbCinsiyet";
            CmbCinsiyet.Size = new Size(193, 33);
            CmbCinsiyet.TabIndex = 6;
            // 
            // FrmBilgiDüzenle
            // 
            AutoScaleDimensions = new SizeF(13F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            AutoSizeMode = AutoSizeMode.GrowAndShrink;
            BackColor = Color.LightSeaGreen;
            ClientSize = new Size(1362, 743);
            Controls.Add(CmbCinsiyet);
            Controls.Add(BtnBilgiGuncelle);
            Controls.Add(pictureBox1);
            Controls.Add(TxtSifre);
            Controls.Add(MskdTel);
            Controls.Add(MskdTC);
            Controls.Add(TxtSoyad);
            Controls.Add(TxtAd);
            Controls.Add(label6);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Font = new Font("Modern No. 20", 13.7999992F, FontStyle.Regular, GraphicsUnit.Point, 0);
            Margin = new Padding(5, 4, 5, 4);
            MaximizeBox = false;
            Name = "FrmBilgiDüzenle";
            Text = "Bilgi Güncelleme ";
            WindowState = FormWindowState.Maximized;
            Load += FrmBilgiDüzenle_Load;
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button BtnBilgiGuncelle;
        private PictureBox pictureBox1;
        private TextBox TxtSifre;
        private MaskedTextBox MskdTel;
        private MaskedTextBox MskdTC;
        private TextBox TxtSoyad;
        private TextBox TxtAd;
        private Label label6;
        private Label label5;
        private Label label4;
        private Label label3;
        private Label label2;
        private Label label1;
        private ComboBox CmbCinsiyet;
    }
}