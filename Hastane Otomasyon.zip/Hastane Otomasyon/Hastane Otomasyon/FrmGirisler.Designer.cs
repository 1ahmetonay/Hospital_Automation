﻿namespace Hastane_Otomasyon
{
    partial class FrmGirisler
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmGirisler));
            btnHasta = new Button();
            btnDoktorGiris = new Button();
            btnSekreterGiris = new Button();
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            pictureBox1 = new PictureBox();
            label4 = new Label();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // btnHasta
            // 
            btnHasta.Anchor = AnchorStyles.None;
            btnHasta.BackgroundImage = (Image)resources.GetObject("btnHasta.BackgroundImage");
            btnHasta.BackgroundImageLayout = ImageLayout.Stretch;
            btnHasta.Location = new Point(211, 314);
            btnHasta.Name = "btnHasta";
            btnHasta.Size = new Size(253, 240);
            btnHasta.TabIndex = 0;
            btnHasta.UseVisualStyleBackColor = true;
            btnHasta.Click += btnHasta_Click;
            // 
            // btnDoktorGiris
            // 
            btnDoktorGiris.Anchor = AnchorStyles.None;
            btnDoktorGiris.BackgroundImage = (Image)resources.GetObject("btnDoktorGiris.BackgroundImage");
            btnDoktorGiris.BackgroundImageLayout = ImageLayout.Stretch;
            btnDoktorGiris.Location = new Point(533, 314);
            btnDoktorGiris.Name = "btnDoktorGiris";
            btnDoktorGiris.Size = new Size(264, 240);
            btnDoktorGiris.TabIndex = 1;
            btnDoktorGiris.UseVisualStyleBackColor = true;
            btnDoktorGiris.Click += btnDoktorGiris_Click;
            // 
            // btnSekreterGiris
            // 
            btnSekreterGiris.Anchor = AnchorStyles.None;
            btnSekreterGiris.BackgroundImage = (Image)resources.GetObject("btnSekreterGiris.BackgroundImage");
            btnSekreterGiris.BackgroundImageLayout = ImageLayout.Stretch;
            btnSekreterGiris.Location = new Point(860, 314);
            btnSekreterGiris.Name = "btnSekreterGiris";
            btnSekreterGiris.Size = new Size(257, 240);
            btnSekreterGiris.TabIndex = 2;
            btnSekreterGiris.UseVisualStyleBackColor = true;
            btnSekreterGiris.Click += btnSekreterGiris_Click;
            // 
            // label1
            // 
            label1.Anchor = AnchorStyles.None;
            label1.AutoSize = true;
            label1.Font = new Font("Modern No. 20", 36F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            label1.Location = new Point(246, 559);
            label1.Name = "label1";
            label1.Size = new Size(177, 62);
            label1.TabIndex = 3;
            label1.Text = "Hasta";
            // 
            // label2
            // 
            label2.Anchor = AnchorStyles.None;
            label2.AutoSize = true;
            label2.Font = new Font("Modern No. 20", 36F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label2.Location = new Point(566, 557);
            label2.Name = "label2";
            label2.Size = new Size(200, 62);
            label2.TabIndex = 4;
            label2.Text = "Doktor";
            // 
            // label3
            // 
            label3.Anchor = AnchorStyles.None;
            label3.AutoSize = true;
            label3.Font = new Font("Modern No. 20", 36F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            label3.Location = new Point(869, 559);
            label3.Name = "label3";
            label3.Size = new Size(238, 62);
            label3.TabIndex = 5;
            label3.Text = "Sekreter";
            // 
            // pictureBox1
            // 
            pictureBox1.Anchor = AnchorStyles.None;
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(831, 41);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(249, 215);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 6;
            pictureBox1.TabStop = false;
            // 
            // label4
            // 
            label4.Anchor = AnchorStyles.None;
            label4.AutoSize = true;
            label4.Font = new Font("Modern No. 20", 72F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            label4.Location = new Point(274, 88);
            label4.Name = "label4";
            label4.Size = new Size(480, 123);
            label4.TabIndex = 7;
            label4.Text = "Hosbital";
            // 
            // FrmGirisler
            // 
            AutoScaleDimensions = new SizeF(14F, 27F);
            AutoScaleMode = AutoScaleMode.Font;
            AutoSizeMode = AutoSizeMode.GrowAndShrink;
            BackColor = Color.LightSeaGreen;
            ClientSize = new Size(1362, 743);
            Controls.Add(label4);
            Controls.Add(pictureBox1);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(btnSekreterGiris);
            Controls.Add(btnDoktorGiris);
            Controls.Add(btnHasta);
            Font = new Font("Georgia", 13.8F, FontStyle.Regular, GraphicsUnit.Point, 162);
            Margin = new Padding(5, 4, 5, 4);
            MaximizeBox = false;
            Name = "FrmGirisler";
            Text = "Hosbital Giriş";
            WindowState = FormWindowState.Maximized;
            Load += Form1_Load;
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button btnHasta;
        private Button btnDoktorGiris;
        private Button btnSekreterGiris;
        private Label label1;
        private Label label2;
        private Label label3;
        private PictureBox pictureBox1;
        private Label label4;
    }
}
