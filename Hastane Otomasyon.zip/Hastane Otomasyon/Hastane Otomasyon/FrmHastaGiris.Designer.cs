﻿namespace Hastane_Otomasyon
{
    partial class FrmHastaGiris
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmHastaGiris));
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            MskTc = new MaskedTextBox();
            TxtSifre = new TextBox();
            LnkUye = new LinkLabel();
            BtnGiris = new Button();
            pictureBox1 = new PictureBox();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // label1
            // 
            label1.Anchor = AnchorStyles.None;
            label1.AutoSize = true;
            label1.Font = new Font("Modern No. 20", 72F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            label1.Location = new Point(165, 28);
            label1.Name = "label1";
            label1.Size = new Size(999, 123);
            label1.TabIndex = 0;
            label1.Text = "Hasta Giriş Paneli";
            // 
            // label2
            // 
            label2.Anchor = AnchorStyles.None;
            label2.AutoSize = true;
            label2.Font = new Font("Modern No. 20", 24F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            label2.Location = new Point(511, 287);
            label2.Name = "label2";
            label2.Size = new Size(115, 41);
            label2.TabIndex = 1;
            label2.Text = "Şifre:";
            // 
            // label3
            // 
            label3.Anchor = AnchorStyles.None;
            label3.AutoSize = true;
            label3.Font = new Font("Modern No. 20", 24F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            label3.Location = new Point(362, 225);
            label3.Name = "label3";
            label3.Size = new Size(272, 41);
            label3.TabIndex = 2;
            label3.Text = "TC Kimlik No:";
            // 
            // MskTc
            // 
            MskTc.Anchor = AnchorStyles.None;
            MskTc.Location = new Point(630, 225);
            MskTc.Mask = "00000000000";
            MskTc.Name = "MskTc";
            MskTc.Size = new Size(179, 34);
            MskTc.TabIndex = 3;
            MskTc.ValidatingType = typeof(int);
            // 
            // TxtSifre
            // 
            TxtSifre.Anchor = AnchorStyles.None;
            TxtSifre.Location = new Point(630, 294);
            TxtSifre.Name = "TxtSifre";
            TxtSifre.Size = new Size(179, 34);
            TxtSifre.TabIndex = 4;
            TxtSifre.UseSystemPasswordChar = true;
            // 
            // LnkUye
            // 
            LnkUye.Anchor = AnchorStyles.None;
            LnkUye.AutoSize = true;
            LnkUye.Font = new Font("Modern No. 20", 13.7999992F, FontStyle.Bold, GraphicsUnit.Point, 0);
            LnkUye.Location = new Point(845, 373);
            LnkUye.Name = "LnkUye";
            LnkUye.Size = new Size(81, 25);
            LnkUye.TabIndex = 5;
            LnkUye.TabStop = true;
            LnkUye.Text = "Üye Ol";
            LnkUye.LinkClicked += LnkUye_LinkClicked;
            // 
            // BtnGiris
            // 
            BtnGiris.Anchor = AnchorStyles.None;
            BtnGiris.Font = new Font("Modern No. 20", 24F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            BtnGiris.Location = new Point(653, 352);
            BtnGiris.Name = "BtnGiris";
            BtnGiris.Size = new Size(136, 46);
            BtnGiris.TabIndex = 6;
            BtnGiris.Text = "Giriş";
            BtnGiris.UseVisualStyleBackColor = true;
            BtnGiris.Click += BtnGiris_Click;
            // 
            // pictureBox1
            // 
            pictureBox1.Anchor = AnchorStyles.None;
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(-6, 472);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(1375, 273);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 7;
            pictureBox1.TabStop = false;
            // 
            // FrmHastaGiris
            // 
            AutoScaleDimensions = new SizeF(14F, 27F);
            AutoScaleMode = AutoScaleMode.Font;
            AutoSizeMode = AutoSizeMode.GrowAndShrink;
            BackColor = Color.LightSeaGreen;
            ClientSize = new Size(1362, 743);
            Controls.Add(pictureBox1);
            Controls.Add(BtnGiris);
            Controls.Add(LnkUye);
            Controls.Add(TxtSifre);
            Controls.Add(MskTc);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Font = new Font("Georgia", 13.8F, FontStyle.Regular, GraphicsUnit.Point, 162);
            Margin = new Padding(5, 4, 5, 4);
            MaximizeBox = false;
            Name = "FrmHastaGiris";
            Text = "Hasta Girişi";
            WindowState = FormWindowState.Maximized;
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label label2;
        private Label label3;
        private MaskedTextBox MskTc;
        private TextBox TxtSifre;
        private LinkLabel LnkUye;
        private Button BtnGiris;
        private PictureBox pictureBox1;
    }
}