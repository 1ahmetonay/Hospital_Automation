﻿namespace Hastane_Otomasyon
{
    partial class Frm_SekreterGiris
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Frm_SekreterGiris));
            pictureBox1 = new PictureBox();
            BtnGiris = new Button();
            TxtSifre = new TextBox();
            MskTc = new MaskedTextBox();
            label3 = new Label();
            label2 = new Label();
            label1 = new Label();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // pictureBox1
            // 
            pictureBox1.Anchor = AnchorStyles.None;
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(-2, 447);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(1367, 290);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 22;
            pictureBox1.TabStop = false;
            // 
            // BtnGiris
            // 
            BtnGiris.Anchor = AnchorStyles.None;
            BtnGiris.BackColor = Color.CadetBlue;
            BtnGiris.Font = new Font("Modern No. 20", 24F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            BtnGiris.Location = new Point(670, 281);
            BtnGiris.Name = "BtnGiris";
            BtnGiris.Size = new Size(136, 46);
            BtnGiris.TabIndex = 21;
            BtnGiris.Text = "Giriş";
            BtnGiris.UseVisualStyleBackColor = false;
            BtnGiris.Click += BtnGiris_Click;
            // 
            // TxtSifre
            // 
            TxtSifre.Anchor = AnchorStyles.None;
            TxtSifre.Location = new Point(647, 223);
            TxtSifre.Name = "TxtSifre";
            TxtSifre.Size = new Size(179, 34);
            TxtSifre.TabIndex = 20;
            TxtSifre.UseSystemPasswordChar = true;
            // 
            // MskTc
            // 
            MskTc.Anchor = AnchorStyles.None;
            MskTc.Location = new Point(647, 154);
            MskTc.Mask = "00000000000";
            MskTc.Name = "MskTc";
            MskTc.Size = new Size(179, 34);
            MskTc.TabIndex = 19;
            MskTc.ValidatingType = typeof(int);
            // 
            // label3
            // 
            label3.Anchor = AnchorStyles.None;
            label3.AutoSize = true;
            label3.Font = new Font("Modern No. 20", 24F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            label3.Location = new Point(379, 154);
            label3.Name = "label3";
            label3.Size = new Size(272, 41);
            label3.TabIndex = 18;
            label3.Text = "TC Kimlik No:";
            // 
            // label2
            // 
            label2.Anchor = AnchorStyles.None;
            label2.AutoSize = true;
            label2.Font = new Font("Modern No. 20", 24F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            label2.Location = new Point(528, 216);
            label2.Name = "label2";
            label2.Size = new Size(115, 41);
            label2.TabIndex = 17;
            label2.Text = "Şifre:";
            // 
            // label1
            // 
            label1.Anchor = AnchorStyles.None;
            label1.AutoSize = true;
            label1.Font = new Font("Modern No. 20", 48F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            label1.Location = new Point(259, 7);
            label1.Name = "label1";
            label1.Size = new Size(751, 83);
            label1.TabIndex = 16;
            label1.Text = "Sekreter Giriş Paneli";
            // 
            // Frm_SekreterGiris
            // 
            AutoScaleDimensions = new SizeF(14F, 27F);
            AutoScaleMode = AutoScaleMode.Font;
            AutoSizeMode = AutoSizeMode.GrowAndShrink;
            BackColor = Color.LightSeaGreen;
            ClientSize = new Size(1362, 743);
            Controls.Add(pictureBox1);
            Controls.Add(BtnGiris);
            Controls.Add(TxtSifre);
            Controls.Add(MskTc);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Font = new Font("Georgia", 13.8F, FontStyle.Regular, GraphicsUnit.Point, 162);
            Margin = new Padding(5, 4, 5, 4);
            MaximizeBox = false;
            Name = "Frm_SekreterGiris";
            Text = "Sekreter Giriş ";
            WindowState = FormWindowState.Maximized;
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private PictureBox pictureBox1;
        private Button BtnGiris;
        private TextBox TxtSifre;
        private MaskedTextBox MskTc;
        private Label label3;
        private Label label2;
        private Label label1;
    }
}