﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using Microsoft.Data.SqlClient;
using System.Data.SqlClient;

namespace Hastane_Otomasyon
{
    public partial class FrmRandevuList : Form
    {
        public FrmRandevuList()
        {
            InitializeComponent();
        }
        Sql_Baglantisi bgl = new Sql_Baglantisi();
        private void FrmRandevuList_Load(object sender, EventArgs e)
        {
            DataTable dt = new DataTable();
            SqlDataAdapter da = new SqlDataAdapter("Select * From Tbl_Randevular", bgl.baglanti());
            da.Fill(dt);
            dataGridView1.DataSource = dt;
        }

    }
}
