﻿namespace Hastane_Otomasyon
{
    partial class FrmDoktorPaneli
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label7 = new Label();
            label6 = new Label();
            label5 = new Label();
            label4 = new Label();
            label3 = new Label();
            TxtAd = new TextBox();
            TxtSoyad = new TextBox();
            TxtSifre = new TextBox();
            MtxtTc = new MaskedTextBox();
            CmbBrans = new ComboBox();
            BtnEkle = new Button();
            BtnSil = new Button();
            BtnGuncelle = new Button();
            DgvDoktorP = new DataGridView();
            ((System.ComponentModel.ISupportInitialize)DgvDoktorP).BeginInit();
            SuspendLayout();
            // 
            // label7
            // 
            label7.Anchor = AnchorStyles.None;
            label7.AutoSize = true;
            label7.Font = new Font("Georgia", 18F);
            label7.Location = new Point(45, 436);
            label7.Name = "label7";
            label7.Size = new Size(94, 35);
            label7.TabIndex = 19;
            label7.Text = "Şifre :";
            // 
            // label6
            // 
            label6.Anchor = AnchorStyles.None;
            label6.AutoSize = true;
            label6.Font = new Font("Georgia", 18F);
            label6.Location = new Point(24, 368);
            label6.Name = "label6";
            label6.Size = new Size(115, 35);
            label6.TabIndex = 18;
            label6.Text = "TC No :";
            // 
            // label5
            // 
            label5.Anchor = AnchorStyles.None;
            label5.AutoSize = true;
            label5.Font = new Font("Georgia", 18F);
            label5.Location = new Point(30, 300);
            label5.Name = "label5";
            label5.Size = new Size(109, 35);
            label5.TabIndex = 17;
            label5.Text = "Branş :";
            // 
            // label4
            // 
            label4.Anchor = AnchorStyles.None;
            label4.AutoSize = true;
            label4.Font = new Font("Georgia", 18F);
            label4.Location = new Point(28, 232);
            label4.Name = "label4";
            label4.Size = new Size(111, 35);
            label4.TabIndex = 16;
            label4.Text = "Soyad :";
            // 
            // label3
            // 
            label3.Anchor = AnchorStyles.None;
            label3.AutoSize = true;
            label3.Font = new Font("Georgia", 18F);
            label3.Location = new Point(71, 164);
            label3.Name = "label3";
            label3.Size = new Size(68, 35);
            label3.TabIndex = 15;
            label3.Text = "Ad :";
            // 
            // TxtAd
            // 
            TxtAd.Anchor = AnchorStyles.None;
            TxtAd.Location = new Point(145, 165);
            TxtAd.Name = "TxtAd";
            TxtAd.Size = new Size(198, 34);
            TxtAd.TabIndex = 1;
            // 
            // TxtSoyad
            // 
            TxtSoyad.Anchor = AnchorStyles.None;
            TxtSoyad.Location = new Point(145, 232);
            TxtSoyad.Name = "TxtSoyad";
            TxtSoyad.Size = new Size(198, 34);
            TxtSoyad.TabIndex = 2;
            // 
            // TxtSifre
            // 
            TxtSifre.Anchor = AnchorStyles.None;
            TxtSifre.Location = new Point(145, 434);
            TxtSifre.Name = "TxtSifre";
            TxtSifre.Size = new Size(198, 34);
            TxtSifre.TabIndex = 5;
            // 
            // MtxtTc
            // 
            MtxtTc.Anchor = AnchorStyles.None;
            MtxtTc.Location = new Point(145, 367);
            MtxtTc.Mask = "00000000000";
            MtxtTc.Name = "MtxtTc";
            MtxtTc.Size = new Size(198, 34);
            MtxtTc.TabIndex = 4;
            // 
            // CmbBrans
            // 
            CmbBrans.Anchor = AnchorStyles.None;
            CmbBrans.FormattingEnabled = true;
            CmbBrans.Location = new Point(145, 299);
            CmbBrans.Name = "CmbBrans";
            CmbBrans.Size = new Size(198, 35);
            CmbBrans.TabIndex = 3;
            // 
            // BtnEkle
            // 
            BtnEkle.Anchor = AnchorStyles.None;
            BtnEkle.BackColor = Color.Green;
            BtnEkle.Location = new Point(64, 497);
            BtnEkle.Name = "BtnEkle";
            BtnEkle.Size = new Size(135, 44);
            BtnEkle.TabIndex = 6;
            BtnEkle.Text = "Ekle ";
            BtnEkle.UseVisualStyleBackColor = false;
            BtnEkle.Click += BtnEkle_Click;
            // 
            // BtnSil
            // 
            BtnSil.Anchor = AnchorStyles.None;
            BtnSil.BackColor = Color.Red;
            BtnSil.Location = new Point(208, 497);
            BtnSil.Name = "BtnSil";
            BtnSil.Size = new Size(135, 44);
            BtnSil.TabIndex = 7;
            BtnSil.Text = "Sil";
            BtnSil.UseVisualStyleBackColor = false;
            BtnSil.Click += BtnSil_Click;
            // 
            // BtnGuncelle
            // 
            BtnGuncelle.Anchor = AnchorStyles.None;
            BtnGuncelle.BackColor = Color.CadetBlue;
            BtnGuncelle.Location = new Point(64, 547);
            BtnGuncelle.Name = "BtnGuncelle";
            BtnGuncelle.Size = new Size(279, 52);
            BtnGuncelle.TabIndex = 8;
            BtnGuncelle.Text = "Güncelle";
            BtnGuncelle.UseVisualStyleBackColor = false;
            BtnGuncelle.Click += BtnGuncelle_Click;
            // 
            // DgvDoktorP
            // 
            DgvDoktorP.Anchor = AnchorStyles.None;
            DgvDoktorP.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            DgvDoktorP.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            DgvDoktorP.Location = new Point(385, 165);
            DgvDoktorP.Name = "DgvDoktorP";
            DgvDoktorP.RowHeadersWidth = 51;
            DgvDoktorP.Size = new Size(931, 434);
            DgvDoktorP.TabIndex = 28;
            DgvDoktorP.CellClick += DgvDoktorP_CellClick;
            // 
            // FrmDoktorPaneli
            // 
            AutoScaleDimensions = new SizeF(14F, 27F);
            AutoScaleMode = AutoScaleMode.Font;
            AutoSizeMode = AutoSizeMode.GrowAndShrink;
            BackColor = Color.LightSeaGreen;
            ClientSize = new Size(1362, 743);
            Controls.Add(DgvDoktorP);
            Controls.Add(BtnGuncelle);
            Controls.Add(BtnSil);
            Controls.Add(BtnEkle);
            Controls.Add(CmbBrans);
            Controls.Add(MtxtTc);
            Controls.Add(TxtSifre);
            Controls.Add(TxtSoyad);
            Controls.Add(TxtAd);
            Controls.Add(label7);
            Controls.Add(label6);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(label3);
            Font = new Font("Georgia", 13.8F, FontStyle.Regular, GraphicsUnit.Point, 162);
            Margin = new Padding(5, 4, 5, 4);
            MaximizeBox = false;
            Name = "FrmDoktorPaneli";
            Text = "Doktor Paneli";
            WindowState = FormWindowState.Maximized;
            Load += FrmDoktorPaneli_Load;
            ((System.ComponentModel.ISupportInitialize)DgvDoktorP).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label7;
        private Label label6;
        private Label label5;
        private Label label4;
        private Label label3;
        private TextBox TxtAd;
        private TextBox TxtSoyad;
        private TextBox TxtSifre;
        private MaskedTextBox MtxtTc;
        private ComboBox CmbBrans;
        private Button BtnEkle;
        private Button BtnSil;
        private Button BtnGuncelle;
        private DataGridView DgvDoktorP;
    }
}