﻿namespace Hastane_Otomasyon
{
    partial class FrmDoktorBilgiGüncelle
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmDoktorBilgiGüncelle));
            BtnBilgiGuncelle = new Button();
            pictureBox1 = new PictureBox();
            TxtSifre = new TextBox();
            MskdTC = new MaskedTextBox();
            TxtSoyad = new TextBox();
            TxtAd = new TextBox();
            label5 = new Label();
            label4 = new Label();
            label3 = new Label();
            label2 = new Label();
            label1 = new Label();
            CmbBrans = new ComboBox();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // BtnBilgiGuncelle
            // 
            BtnBilgiGuncelle.Anchor = AnchorStyles.None;
            BtnBilgiGuncelle.BackColor = Color.Green;
            BtnBilgiGuncelle.Font = new Font("Georgia", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 162);
            BtnBilgiGuncelle.Location = new Point(398, 471);
            BtnBilgiGuncelle.Name = "BtnBilgiGuncelle";
            BtnBilgiGuncelle.Size = new Size(193, 79);
            BtnBilgiGuncelle.TabIndex = 44;
            BtnBilgiGuncelle.Text = "Güncelle";
            BtnBilgiGuncelle.UseVisualStyleBackColor = false;
            BtnBilgiGuncelle.Click += BtnBilgiGuncelle_Click;
            // 
            // pictureBox1
            // 
            pictureBox1.Anchor = AnchorStyles.None;
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(647, 202);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(374, 348);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 43;
            pictureBox1.TabStop = false;
            // 
            // TxtSifre
            // 
            TxtSifre.Anchor = AnchorStyles.None;
            TxtSifre.Location = new Point(398, 395);
            TxtSifre.Name = "TxtSifre";
            TxtSifre.Size = new Size(193, 34);
            TxtSifre.TabIndex = 40;
            // 
            // MskdTC
            // 
            MskdTC.Anchor = AnchorStyles.None;
            MskdTC.Location = new Point(398, 297);
            MskdTC.Mask = "00000000000";
            MskdTC.Name = "MskdTC";
            MskdTC.Size = new Size(193, 34);
            MskdTC.TabIndex = 38;
            MskdTC.ValidatingType = typeof(int);
            // 
            // TxtSoyad
            // 
            TxtSoyad.Anchor = AnchorStyles.None;
            TxtSoyad.Location = new Point(398, 249);
            TxtSoyad.Name = "TxtSoyad";
            TxtSoyad.Size = new Size(193, 34);
            TxtSoyad.TabIndex = 37;
            // 
            // TxtAd
            // 
            TxtAd.Anchor = AnchorStyles.None;
            TxtAd.Location = new Point(398, 199);
            TxtAd.Name = "TxtAd";
            TxtAd.Size = new Size(193, 34);
            TxtAd.TabIndex = 36;
            // 
            // label5
            // 
            label5.Anchor = AnchorStyles.None;
            label5.AutoSize = true;
            label5.Font = new Font("Georgia", 18F);
            label5.Location = new Point(304, 398);
            label5.Name = "label5";
            label5.Size = new Size(87, 35);
            label5.TabIndex = 34;
            label5.Text = "Şifre:";
            // 
            // label4
            // 
            label4.Anchor = AnchorStyles.None;
            label4.AutoSize = true;
            label4.Font = new Font("Georgia", 18F);
            label4.Location = new Point(291, 349);
            label4.Name = "label4";
            label4.Size = new Size(102, 35);
            label4.TabIndex = 33;
            label4.Text = "Branş:";
            // 
            // label3
            // 
            label3.Anchor = AnchorStyles.None;
            label3.AutoSize = true;
            label3.Font = new Font("Georgia", 18F);
            label3.Location = new Point(286, 300);
            label3.Name = "label3";
            label3.Size = new Size(108, 35);
            label3.TabIndex = 32;
            label3.Text = "TC No:";
            // 
            // label2
            // 
            label2.Anchor = AnchorStyles.None;
            label2.AutoSize = true;
            label2.Font = new Font("Georgia", 18F);
            label2.Location = new Point(290, 251);
            label2.Name = "label2";
            label2.Size = new Size(104, 35);
            label2.TabIndex = 31;
            label2.Text = "Soyad:";
            // 
            // label1
            // 
            label1.Anchor = AnchorStyles.None;
            label1.AutoSize = true;
            label1.Font = new Font("Georgia", 18F);
            label1.Location = new Point(323, 202);
            label1.Name = "label1";
            label1.Size = new Size(61, 35);
            label1.TabIndex = 30;
            label1.Text = "Ad:";
            // 
            // CmbBrans
            // 
            CmbBrans.Anchor = AnchorStyles.None;
            CmbBrans.FormattingEnabled = true;
            CmbBrans.Location = new Point(398, 344);
            CmbBrans.Name = "CmbBrans";
            CmbBrans.Size = new Size(193, 35);
            CmbBrans.TabIndex = 45;
            // 
            // FrmDoktorBilgiGüncelle
            // 
            AutoScaleDimensions = new SizeF(14F, 27F);
            AutoScaleMode = AutoScaleMode.Font;
            AutoSizeMode = AutoSizeMode.GrowAndShrink;
            BackColor = Color.LightSeaGreen;
            ClientSize = new Size(1362, 743);
            Controls.Add(CmbBrans);
            Controls.Add(BtnBilgiGuncelle);
            Controls.Add(pictureBox1);
            Controls.Add(TxtSifre);
            Controls.Add(MskdTC);
            Controls.Add(TxtSoyad);
            Controls.Add(TxtAd);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Font = new Font("Georgia", 13.8F, FontStyle.Regular, GraphicsUnit.Point, 162);
            Margin = new Padding(5, 4, 5, 4);
            MaximizeBox = false;
            Name = "FrmDoktorBilgiGüncelle";
            Text = "Doktor Bilgi Güncelle";
            WindowState = FormWindowState.Maximized;
            Load += FrmDoktorBilgiGüncelle_Load;
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button BtnBilgiGuncelle;
        private PictureBox pictureBox1;
        private TextBox TxtSifre;
        private MaskedTextBox MskdTC;
        private TextBox TxtSoyad;
        private TextBox TxtAd;
        private Label label5;
        private Label label4;
        private Label label3;
        private Label label2;
        private Label label1;
        private ComboBox CmbBrans;
    }
}