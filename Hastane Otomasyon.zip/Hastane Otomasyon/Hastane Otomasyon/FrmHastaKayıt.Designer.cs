﻿namespace Hastane_Otomasyon
{
    partial class FrmHastaKayıt
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmHastaKayıt));
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            label5 = new Label();
            label6 = new Label();
            TxtAd = new TextBox();
            TxtSoyad = new TextBox();
            MskdTC = new MaskedTextBox();
            MskdTel = new MaskedTextBox();
            TxtSifre = new TextBox();
            pictureBox1 = new PictureBox();
            btnkayıt = new Button();
            CmbCinsiyet = new ComboBox();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // label1
            // 
            label1.Anchor = AnchorStyles.None;
            label1.AutoSize = true;
            label1.Font = new Font("Georgia", 18F);
            label1.Location = new Point(361, 146);
            label1.Name = "label1";
            label1.Size = new Size(61, 35);
            label1.TabIndex = 0;
            label1.Text = "Ad:";
            // 
            // label2
            // 
            label2.Anchor = AnchorStyles.None;
            label2.AutoSize = true;
            label2.Font = new Font("Georgia", 18F);
            label2.Location = new Point(318, 205);
            label2.Name = "label2";
            label2.Size = new Size(104, 35);
            label2.TabIndex = 1;
            label2.Text = "Soyad:";
            // 
            // label3
            // 
            label3.Anchor = AnchorStyles.None;
            label3.AutoSize = true;
            label3.Font = new Font("Georgia", 18F);
            label3.Location = new Point(314, 266);
            label3.Name = "label3";
            label3.Size = new Size(108, 35);
            label3.TabIndex = 2;
            label3.Text = "TC No:";
            // 
            // label4
            // 
            label4.Anchor = AnchorStyles.None;
            label4.AutoSize = true;
            label4.Font = new Font("Georgia", 18F);
            label4.Location = new Point(296, 326);
            label4.Name = "label4";
            label4.Size = new Size(126, 35);
            label4.TabIndex = 3;
            label4.Text = "Telefon:";
            // 
            // label5
            // 
            label5.Anchor = AnchorStyles.None;
            label5.AutoSize = true;
            label5.Font = new Font("Georgia", 18F);
            label5.Location = new Point(335, 384);
            label5.Name = "label5";
            label5.Size = new Size(87, 35);
            label5.TabIndex = 4;
            label5.Text = "Şifre:";
            // 
            // label6
            // 
            label6.Anchor = AnchorStyles.None;
            label6.AutoSize = true;
            label6.Font = new Font("Georgia", 18F);
            label6.Location = new Point(290, 441);
            label6.Name = "label6";
            label6.Size = new Size(132, 35);
            label6.TabIndex = 5;
            label6.Text = "Cinsiyet:";
            // 
            // TxtAd
            // 
            TxtAd.Anchor = AnchorStyles.None;
            TxtAd.Location = new Point(426, 145);
            TxtAd.Name = "TxtAd";
            TxtAd.Size = new Size(194, 34);
            TxtAd.TabIndex = 1;
            // 
            // TxtSoyad
            // 
            TxtSoyad.Anchor = AnchorStyles.None;
            TxtSoyad.Location = new Point(426, 204);
            TxtSoyad.Name = "TxtSoyad";
            TxtSoyad.Size = new Size(194, 34);
            TxtSoyad.TabIndex = 2;
            // 
            // MskdTC
            // 
            MskdTC.Anchor = AnchorStyles.None;
            MskdTC.Location = new Point(426, 263);
            MskdTC.Mask = "00000000000";
            MskdTC.Name = "MskdTC";
            MskdTC.Size = new Size(194, 34);
            MskdTC.TabIndex = 3;
            MskdTC.ValidatingType = typeof(int);
            // 
            // MskdTel
            // 
            MskdTel.Anchor = AnchorStyles.None;
            MskdTel.Location = new Point(426, 322);
            MskdTel.Mask = "(999) 000-0000";
            MskdTel.Name = "MskdTel";
            MskdTel.Size = new Size(194, 34);
            MskdTel.TabIndex = 4;
            // 
            // TxtSifre
            // 
            TxtSifre.Anchor = AnchorStyles.None;
            TxtSifre.Location = new Point(426, 381);
            TxtSifre.Name = "TxtSifre";
            TxtSifre.Size = new Size(194, 34);
            TxtSifre.TabIndex = 5;
            // 
            // pictureBox1
            // 
            pictureBox1.Anchor = AnchorStyles.None;
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(681, 146);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(387, 414);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 13;
            pictureBox1.TabStop = false;
            // 
            // btnkayıt
            // 
            btnkayıt.Anchor = AnchorStyles.None;
            btnkayıt.BackColor = Color.FromArgb(0, 192, 0);
            btnkayıt.Font = new Font("Georgia", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 162);
            btnkayıt.Location = new Point(426, 492);
            btnkayıt.Name = "btnkayıt";
            btnkayıt.Size = new Size(193, 68);
            btnkayıt.TabIndex = 7;
            btnkayıt.Text = "Kayıt";
            btnkayıt.UseVisualStyleBackColor = false;
            btnkayıt.Click += btnkayıt_Click;
            // 
            // CmbCinsiyet
            // 
            CmbCinsiyet.Anchor = AnchorStyles.None;
            CmbCinsiyet.FormattingEnabled = true;
            CmbCinsiyet.Items.AddRange(new object[] { "Kadın", "Erkek" });
            CmbCinsiyet.Location = new Point(425, 440);
            CmbCinsiyet.Name = "CmbCinsiyet";
            CmbCinsiyet.Size = new Size(194, 35);
            CmbCinsiyet.TabIndex = 6;
            // 
            // FrmHastaKayıt
            // 
            AutoScaleDimensions = new SizeF(14F, 27F);
            AutoScaleMode = AutoScaleMode.Font;
            AutoSizeMode = AutoSizeMode.GrowAndShrink;
            BackColor = Color.LightSeaGreen;
            ClientSize = new Size(1362, 743);
            Controls.Add(CmbCinsiyet);
            Controls.Add(btnkayıt);
            Controls.Add(pictureBox1);
            Controls.Add(TxtSifre);
            Controls.Add(MskdTel);
            Controls.Add(MskdTC);
            Controls.Add(TxtSoyad);
            Controls.Add(TxtAd);
            Controls.Add(label6);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Font = new Font("Georgia", 13.8F, FontStyle.Regular, GraphicsUnit.Point, 162);
            Margin = new Padding(5, 4, 5, 4);
            MaximizeBox = false;
            Name = "FrmHastaKayıt";
            Text = "Hasta Kayıt";
            WindowState = FormWindowState.Maximized;
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private Label label5;
        private Label label6;
        private TextBox TxtAd;
        private TextBox TxtSoyad;
        private MaskedTextBox MskdTC;
        private MaskedTextBox MskdTel;
        private TextBox TxtSifre;
        private PictureBox pictureBox1;
        private Button btnkayıt;
        private ComboBox CmbCinsiyet;
    }
}