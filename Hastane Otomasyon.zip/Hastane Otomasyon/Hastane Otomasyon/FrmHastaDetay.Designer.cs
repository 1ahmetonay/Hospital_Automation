﻿namespace Hastane_Otomasyon
{
    partial class FrmHastaDetay
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            groupBox1 = new GroupBox();
            LblAdSoyad = new Label();
            LblTC = new Label();
            label2 = new Label();
            label1 = new Label();
            groupBox2 = new GroupBox();
            Txtİd = new TextBox();
            label3 = new Label();
            LnkBilgiDüzenle = new LinkLabel();
            BtnRandevuAl = new Button();
            CmbDoktor = new ComboBox();
            CmbBrans = new ComboBox();
            RtxtŞikayet = new RichTextBox();
            label7 = new Label();
            label6 = new Label();
            label5 = new Label();
            groupBox3 = new GroupBox();
            dataGridView1 = new DataGridView();
            groupBox4 = new GroupBox();
            dataGridView2 = new DataGridView();
            groupBox1.SuspendLayout();
            groupBox2.SuspendLayout();
            groupBox3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            groupBox4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridView2).BeginInit();
            SuspendLayout();
            // 
            // groupBox1
            // 
            groupBox1.Anchor = AnchorStyles.None;
            groupBox1.Controls.Add(LblAdSoyad);
            groupBox1.Controls.Add(LblTC);
            groupBox1.Controls.Add(label2);
            groupBox1.Controls.Add(label1);
            groupBox1.Location = new Point(12, 37);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(323, 167);
            groupBox1.TabIndex = 0;
            groupBox1.TabStop = false;
            groupBox1.Text = "Hasta Bilgi";
            // 
            // LblAdSoyad
            // 
            LblAdSoyad.AutoSize = true;
            LblAdSoyad.Location = new Point(128, 119);
            LblAdSoyad.Name = "LblAdSoyad";
            LblAdSoyad.Size = new Size(57, 27);
            LblAdSoyad.TabIndex = 3;
            LblAdSoyad.Text = "Null";
            // 
            // LblTC
            // 
            LblTC.AutoSize = true;
            LblTC.Location = new Point(128, 57);
            LblTC.Name = "LblTC";
            LblTC.Size = new Size(166, 27);
            LblTC.TabIndex = 3;
            LblTC.Text = "00000000000";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(8, 119);
            label2.Name = "label2";
            label2.Size = new Size(114, 27);
            label2.TabIndex = 3;
            label2.Text = "Ad Soyad:";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(38, 57);
            label1.Name = "label1";
            label1.Size = new Size(84, 27);
            label1.TabIndex = 2;
            label1.Text = "TC No:";
            // 
            // groupBox2
            // 
            groupBox2.Anchor = AnchorStyles.None;
            groupBox2.Controls.Add(Txtİd);
            groupBox2.Controls.Add(label3);
            groupBox2.Controls.Add(LnkBilgiDüzenle);
            groupBox2.Controls.Add(BtnRandevuAl);
            groupBox2.Controls.Add(CmbDoktor);
            groupBox2.Controls.Add(CmbBrans);
            groupBox2.Controls.Add(RtxtŞikayet);
            groupBox2.Controls.Add(label7);
            groupBox2.Controls.Add(label6);
            groupBox2.Controls.Add(label5);
            groupBox2.Location = new Point(12, 250);
            groupBox2.Name = "groupBox2";
            groupBox2.Size = new Size(323, 445);
            groupBox2.TabIndex = 1;
            groupBox2.TabStop = false;
            groupBox2.Text = "Randevu Paneli";
            // 
            // Txtİd
            // 
            Txtİd.Enabled = false;
            Txtİd.Location = new Point(125, 33);
            Txtİd.Name = "Txtİd";
            Txtİd.Size = new Size(180, 34);
            Txtİd.TabIndex = 9;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Georgia", 18F);
            label3.Location = new Point(71, 36);
            label3.Name = "label3";
            label3.Size = new Size(53, 35);
            label3.TabIndex = 8;
            label3.Text = "İd:";
            // 
            // LnkBilgiDüzenle
            // 
            LnkBilgiDüzenle.AutoSize = true;
            LnkBilgiDüzenle.Location = new Point(57, 405);
            LnkBilgiDüzenle.Name = "LnkBilgiDüzenle";
            LnkBilgiDüzenle.Size = new Size(190, 27);
            LnkBilgiDüzenle.TabIndex = 7;
            LnkBilgiDüzenle.TabStop = true;
            LnkBilgiDüzenle.Text = "Bilgileri Güncelle";
            LnkBilgiDüzenle.LinkClicked += LnkBilgiDüzenle_LinkClicked;
            // 
            // BtnRandevuAl
            // 
            BtnRandevuAl.BackColor = Color.FromArgb(0, 192, 0);
            BtnRandevuAl.Font = new Font("Georgia", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 162);
            BtnRandevuAl.Location = new Point(76, 350);
            BtnRandevuAl.Name = "BtnRandevuAl";
            BtnRandevuAl.Size = new Size(157, 41);
            BtnRandevuAl.TabIndex = 6;
            BtnRandevuAl.Text = "Randevu Al";
            BtnRandevuAl.UseVisualStyleBackColor = false;
            BtnRandevuAl.Click += BtnRandevuAl_Click;
            // 
            // CmbDoktor
            // 
            CmbDoktor.FormattingEnabled = true;
            CmbDoktor.Location = new Point(125, 142);
            CmbDoktor.Name = "CmbDoktor";
            CmbDoktor.Size = new Size(180, 35);
            CmbDoktor.TabIndex = 5;
            CmbDoktor.SelectedIndexChanged += CmbDoktor_SelectedIndexChanged;
            // 
            // CmbBrans
            // 
            CmbBrans.FormattingEnabled = true;
            CmbBrans.Location = new Point(125, 87);
            CmbBrans.Name = "CmbBrans";
            CmbBrans.Size = new Size(180, 35);
            CmbBrans.TabIndex = 2;
            CmbBrans.SelectedIndexChanged += CmbBrans_SelectedIndexChanged;
            // 
            // RtxtŞikayet
            // 
            RtxtŞikayet.Location = new Point(125, 202);
            RtxtŞikayet.Name = "RtxtŞikayet";
            RtxtŞikayet.Size = new Size(180, 132);
            RtxtŞikayet.TabIndex = 4;
            RtxtŞikayet.Text = "";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Georgia", 18F, FontStyle.Regular, GraphicsUnit.Point, 162);
            label7.Location = new Point(3, 200);
            label7.Name = "label7";
            label7.Size = new Size(121, 35);
            label7.TabIndex = 3;
            label7.Text = "Şikayet:";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Georgia", 18F);
            label6.Location = new Point(8, 148);
            label6.Name = "label6";
            label6.Size = new Size(116, 35);
            label6.TabIndex = 3;
            label6.Text = "Doktor:";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Georgia", 18F);
            label5.Location = new Point(22, 92);
            label5.Name = "label5";
            label5.Size = new Size(102, 35);
            label5.TabIndex = 3;
            label5.Text = "Branş:";
            // 
            // groupBox3
            // 
            groupBox3.Anchor = AnchorStyles.None;
            groupBox3.Controls.Add(dataGridView1);
            groupBox3.Location = new Point(344, 37);
            groupBox3.Name = "groupBox3";
            groupBox3.Size = new Size(1045, 320);
            groupBox3.TabIndex = 2;
            groupBox3.TabStop = false;
            groupBox3.Text = "Geçmiş Randevular";
            // 
            // dataGridView1
            // 
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Dock = DockStyle.Fill;
            dataGridView1.Location = new Point(3, 30);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.RowHeadersWidth = 51;
            dataGridView1.Size = new Size(1039, 287);
            dataGridView1.TabIndex = 0;
            // 
            // groupBox4
            // 
            groupBox4.Anchor = AnchorStyles.None;
            groupBox4.Controls.Add(dataGridView2);
            groupBox4.Location = new Point(340, 363);
            groupBox4.Name = "groupBox4";
            groupBox4.Size = new Size(1048, 330);
            groupBox4.TabIndex = 3;
            groupBox4.TabStop = false;
            groupBox4.Text = "Aktif Randevular";
            // 
            // dataGridView2
            // 
            dataGridView2.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView2.Dock = DockStyle.Fill;
            dataGridView2.Location = new Point(3, 30);
            dataGridView2.Name = "dataGridView2";
            dataGridView2.RowHeadersWidth = 51;
            dataGridView2.Size = new Size(1042, 297);
            dataGridView2.TabIndex = 1;
            dataGridView2.CellClick += dataGridView2_CellClick;
            // 
            // FrmHastaDetay
            // 
            AutoScaleDimensions = new SizeF(14F, 27F);
            AutoScaleMode = AutoScaleMode.Font;
            AutoSizeMode = AutoSizeMode.GrowAndShrink;
            BackColor = Color.LightSeaGreen;
            ClientSize = new Size(1362, 743);
            Controls.Add(groupBox4);
            Controls.Add(groupBox3);
            Controls.Add(groupBox2);
            Controls.Add(groupBox1);
            Font = new Font("Georgia", 13.8F, FontStyle.Regular, GraphicsUnit.Point, 162);
            Margin = new Padding(5, 4, 5, 4);
            MaximizeBox = false;
            Name = "FrmHastaDetay";
            Text = "Hasta Detay";
            WindowState = FormWindowState.Maximized;
            Load += FrmHastaDetay_Load;
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            groupBox2.ResumeLayout(false);
            groupBox2.PerformLayout();
            groupBox3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            groupBox4.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)dataGridView2).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private GroupBox groupBox1;
        private GroupBox groupBox2;
        private Label LblAdSoyad;
        private Label LblTC;
        private Label label2;
        private Label label1;
        private Label label7;
        private Label label6;
        private Label label5;
        private ComboBox CmbDoktor;
        private ComboBox CmbBrans;
        private RichTextBox RtxtŞikayet;
        private GroupBox groupBox3;
        private DataGridView dataGridView1;
        private GroupBox groupBox4;
        private DataGridView dataGridView2;
        private LinkLabel LnkBilgiDüzenle;
        private Button BtnRandevuAl;
        private TextBox Txtİd;
        private Label label3;
    }
}