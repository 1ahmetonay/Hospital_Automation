﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using Microsoft.Data.SqlClient;
using static System.Runtime.InteropServices.JavaScript.JSType;
using System.Drawing;


namespace Hastane_Otomasyon
{
    internal class Sql_Baglantisi
    {
        public SqlConnection baglanti()
        {
            SqlConnection baglan = new SqlConnection("Data Source = Ahmet; Initial Catalog = HastaneProje; Integrated Security = True; Trust Server Certificate = True");
            baglan.Open();
            return baglan;
        }
    }
}
