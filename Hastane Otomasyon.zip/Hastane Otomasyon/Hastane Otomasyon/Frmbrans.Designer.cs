﻿namespace Hastane_Otomasyon
{
    partial class Frmbrans
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            DataGridView = new DataGridView();
            BtnGuncelle = new Button();
            BtnSil = new Button();
            BtnEkle = new Button();
            TxtAd = new TextBox();
            label7 = new Label();
            label6 = new Label();
            Txtİd = new TextBox();
            ((System.ComponentModel.ISupportInitialize)DataGridView).BeginInit();
            SuspendLayout();
            // 
            // DataGridView
            // 
            DataGridView.Anchor = AnchorStyles.None;
            DataGridView.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            DataGridView.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            DataGridView.Location = new Point(615, 232);
            DataGridView.Name = "DataGridView";
            DataGridView.RowHeadersWidth = 51;
            DataGridView.Size = new Size(593, 262);
            DataGridView.TabIndex = 36;
            DataGridView.CellClick += DataGridView_CellClick;
            // 
            // BtnGuncelle
            // 
            BtnGuncelle.Anchor = AnchorStyles.None;
            BtnGuncelle.BackColor = Color.CadetBlue;
            BtnGuncelle.Location = new Point(386, 431);
            BtnGuncelle.Name = "BtnGuncelle";
            BtnGuncelle.Size = new Size(198, 63);
            BtnGuncelle.TabIndex = 35;
            BtnGuncelle.Text = "Güncelle";
            BtnGuncelle.UseVisualStyleBackColor = false;
            BtnGuncelle.Click += BtnGuncelle_Click;
            // 
            // BtnSil
            // 
            BtnSil.Anchor = AnchorStyles.None;
            BtnSil.BackColor = Color.Red;
            BtnSil.Location = new Point(490, 356);
            BtnSil.Name = "BtnSil";
            BtnSil.Size = new Size(94, 69);
            BtnSil.TabIndex = 34;
            BtnSil.Text = "Sil";
            BtnSil.UseVisualStyleBackColor = false;
            BtnSil.Click += BtnSil_Click;
            // 
            // BtnEkle
            // 
            BtnEkle.Anchor = AnchorStyles.None;
            BtnEkle.BackColor = Color.Green;
            BtnEkle.Location = new Point(386, 356);
            BtnEkle.Name = "BtnEkle";
            BtnEkle.Size = new Size(94, 69);
            BtnEkle.TabIndex = 33;
            BtnEkle.Text = "Ekle ";
            BtnEkle.UseVisualStyleBackColor = false;
            BtnEkle.Click += BtnEkle_Click;
            // 
            // TxtAd
            // 
            TxtAd.Anchor = AnchorStyles.None;
            TxtAd.Location = new Point(386, 296);
            TxtAd.Name = "TxtAd";
            TxtAd.Size = new Size(198, 34);
            TxtAd.TabIndex = 31;
            // 
            // label7
            // 
            label7.Anchor = AnchorStyles.None;
            label7.AutoSize = true;
            label7.Font = new Font("Georgia", 18F);
            label7.Location = new Point(238, 295);
            label7.Name = "label7";
            label7.Size = new Size(153, 35);
            label7.TabIndex = 30;
            label7.Text = "Branş Ad :";
            // 
            // label6
            // 
            label6.Anchor = AnchorStyles.None;
            label6.AutoSize = true;
            label6.Font = new Font("Georgia", 18F);
            label6.Location = new Point(242, 230);
            label6.Name = "label6";
            label6.Size = new Size(145, 35);
            label6.TabIndex = 29;
            label6.Text = "Branş İd :";
            // 
            // Txtİd
            // 
            Txtİd.Anchor = AnchorStyles.None;
            Txtİd.Location = new Point(386, 232);
            Txtİd.Name = "Txtİd";
            Txtİd.Size = new Size(198, 34);
            Txtİd.TabIndex = 37;
            // 
            // Frmbrans
            // 
            AutoScaleDimensions = new SizeF(14F, 27F);
            AutoScaleMode = AutoScaleMode.Font;
            AutoSizeMode = AutoSizeMode.GrowAndShrink;
            BackColor = Color.LightSeaGreen;
            ClientSize = new Size(1362, 743);
            Controls.Add(Txtİd);
            Controls.Add(DataGridView);
            Controls.Add(BtnGuncelle);
            Controls.Add(BtnSil);
            Controls.Add(BtnEkle);
            Controls.Add(TxtAd);
            Controls.Add(label7);
            Controls.Add(label6);
            Font = new Font("Georgia", 13.8F, FontStyle.Regular, GraphicsUnit.Point, 162);
            Margin = new Padding(5, 4, 5, 4);
            MaximizeBox = false;
            Name = "Frmbrans";
            Text = "Branş Paneli";
            WindowState = FormWindowState.Maximized;
            Load += Frmbrans_Load;
            ((System.ComponentModel.ISupportInitialize)DataGridView).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private DataGridView DataGridView;
        private Button BtnGuncelle;
        private Button BtnSil;
        private Button BtnEkle;
        private MaskedTextBox MtxtTc;
        private TextBox TxtAd;
        private Label label7;
        private Label label6;
        private TextBox Txtİd;
    }
}